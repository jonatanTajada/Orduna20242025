package modelo;


public class Contador {
	
    private int n = 0;

    public void incrementar() {
        n++;
    }

    public int get() {
        return n;
    }
}
